# netflix-frontend-html-css
i try to create a netflix landing page using html and css
